echo "Enter a character "
read c
if [ $c == 'a' -o $c == 'A' -o $c == 'e' -o $c == 'E' -o $c == 'i' -o $c == 'I' -o $c == 'o' -o $c == 'O' -o $c == 'u' -o $c == 'u' ]
  then
     echo "$c is a vowel"
fi
