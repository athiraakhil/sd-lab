echo "Enter the number"
read n
echo "Multiplication of $n"
for (( i=1; i<=10; i++))
 do
  echo "$i * $n = $(( $i * $n ))"
done
