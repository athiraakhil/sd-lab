echo "Enter a number"
read a
num=$(( $a % 2 ))
if [ $num -eq 0 ]
  then
     echo "$a is an even number "
else
     echo "$a is an odd number"

fi
