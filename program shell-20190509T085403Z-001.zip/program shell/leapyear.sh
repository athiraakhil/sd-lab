echo "Enter a year "
read n
yr=$(( $n % 4 ))
if [ $yr -eq 0 ]
  then
    echo "$n is leap year"
else
   echo "$n is not leap year"
fi
