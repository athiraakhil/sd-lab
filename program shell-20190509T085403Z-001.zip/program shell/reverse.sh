echo " enter a number"
read n
for (( c=$n; c>=1; c-- ))
 do
  echo "$c"
done
