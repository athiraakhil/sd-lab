for i in {0..10..2}
  do
    echo "Welcome $i times"
done
