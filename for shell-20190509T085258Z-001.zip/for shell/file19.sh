for ((;;))
  do
    echo "Infinite loops [ hit CTRL+C to stop]"
done
