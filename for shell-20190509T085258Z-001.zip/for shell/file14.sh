if [ "$1" == "Monday" ]
 then
     echo "It is Monday"
elif [ "$1" == "Tuesday" ]
  then
     echo "It is Tuesday"
else
   echo "It is not Monday or Tuesday"
fi
